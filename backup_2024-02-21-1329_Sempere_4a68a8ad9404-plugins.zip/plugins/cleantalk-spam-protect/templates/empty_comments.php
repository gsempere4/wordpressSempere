<?php

// Empty comments template
