Translations have moved to
https://translate.wordpress.org/projects/wp-plugins/flamingo

Thank you for your contribution.
