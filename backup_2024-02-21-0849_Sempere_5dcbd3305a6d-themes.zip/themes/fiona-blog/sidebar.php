<?php if ( ! is_active_sidebar( 'fiona-blog-sidebar-primary' ) ) {	return; } ?>
<div id="av-secondary-content" class="av-column-4 av-pt-default av-pb-default wow fadeInUp">
	<section class="sidebar">
		<?php dynamic_sidebar('fiona-blog-sidebar-primary'); ?>
	</section>
</div>